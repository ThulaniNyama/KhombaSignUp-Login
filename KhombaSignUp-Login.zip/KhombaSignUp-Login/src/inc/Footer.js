import React from 'react';
import './Footer.css';

const Footer = () => {
    return (
        <div id="main-footer" >
            <hr />
            <p><a href="https://github.com/ThulaniNyama/KhombaSignUp-Login" target="_blank">Thulani Nyama </a>| &copy; {new Date().getFullYear()} | <a href="http://www.khomba.app">Khomba</a> | All Rights Reserved</p> 
        </div>
    )
}
export default Footer;