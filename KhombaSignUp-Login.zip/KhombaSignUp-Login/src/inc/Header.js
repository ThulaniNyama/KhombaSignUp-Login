import React from 'react';
import './Footer.css'

const Header = () => {
    return (
        <div id="main-header" >
            <title>Khomba</title>
        </div>
    )
}
export default Header;