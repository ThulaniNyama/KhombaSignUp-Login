import React, { Component } from 'react';
import axios from 'axios';
import RecordsList from './RecordsList';

export default class READ extends Component {
    constructor(props) {
        super(props);
        this.state = { users: [] };
    }
    componentDidMount() {
        axios.get('http://localhost/khombaPHP/List.php')
            .then(response => {
                this.setState({ users: response.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }
    usersList() {
        return this.state.users.map(function (object, i) {
            return <RecordsList userObj={object} key={i} />;
        });
    }

    render() {
        return (
            <div id="khombaElements">
            <div id="khombaform">
                <h3 align="center">Khomba Users</h3>
                <table className="table table-striped" style={{ marginTop: 20 }}>
                    <thread>
                        <tr>
                            <th>Name</th>
                            <th>Surname</th>
                            <th>Date of Birth</th>
                            <th>Email</th>
                            <th colSpan="2"></th>
                        </tr>
                    </thread>
                    <tbody>
                        {this.usersList()}
                    </tbody>
                </table>
                </div>
            </div>  
        );
    }
}
