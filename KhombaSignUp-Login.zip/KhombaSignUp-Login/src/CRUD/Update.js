import React, { Component } from 'react';
import axios from 'axios';
import { Redirect } from 'react-router';

export default class CREATE extends Component {

    constructor(props) {
        super(props);
        this.onChangeName = this.onChangeName.bind(this);
        this.onChangeSurname = this.onChangeSurname.bind(this);
        this.onChangeDOB = this.onChangeDOB(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            name: '',
            surname: '',
            dob: '',
            email: '',
            redirect: false
        }
    }

    componentDidMount() {
        axios.get('http://localhost/khombaPHP/GetByID.php?id=' + this.props.match.params.id)
            .then(response => {
                this.setState({
                    name: response.data.name,
                    surname: response.data.surname,
                    dob: response.data.dob,
                    email: response.data.email });
            })
            .catch(function (error) {
                console.log(error);
            })
    }

    onChangeName(e) {
        this.setState({
            name: e.target.value
        });
    }
    onChangeSurname(e) {
        this.setState({
            surname: e.target.value
        });
    }
    onChangeDOB(e) {
        this.setState({
            dob: e.target.value
        });
    }
    onChangeEmail(e) {
        this.setState({
            email: e.target.value
        });
    }

    onSubmit(e) {
        e.preventDefault();

        const userObj = {
            name: this.state.name,
            surname: this.state.surname,
            dob: this.state.dob,
            email: this.state.email
        };
        axios.post('http:localhost/khombaPHP/Update.php?id=' +
            this.props.match.params.id, userObj)
            .then(res => console.log(res.data),
                this.setState({ redirect: true })
        );
    }

    render() {
        return (
            <div style={{ marginTop: 10 }}>
                <h3>Update your details Khomba user :) </h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Name :</label>
                        <input type="text" className="form-control"
                            value={this.state.onChangeName}
                            onChange={this.onChangeName} />
                    </div>
                    <div className="form-group">
                        <label>Surname :</label>
                        <input type="text" className="form-control"
                            value={this.state.onChangeSurname}
                            onChange={this.onChangeSurname} />
                    </div>
                    <div className="form-group">
                        <label>Date of Birth :</label>
                        <input type="date" className="form-control"
                            value={this.state.onChangeDOB}
                            onChange={this.onChangeDOB} />
                    </div>
                    <div className="form-group">
                        <label>Email :</label>
                        <input type="email" className="form-control"
                            value={this.state.onChangeEmail}
                            onChange={this.onChangeEmail} />
                    </div>
                    <div className="form-group">
                        <input type="submit" value="Update User " className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}
