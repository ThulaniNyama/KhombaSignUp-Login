import React, { Component } from 'react';
import axios from 'axios';

export default class Create extends Component {
    constructor(props) {
        super(props);
        this.onChangeName = this.onChangeName.bind(this);
        this.onChangeSurname = this.onChangeSurname.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.onChangeDOB = this.onChangeDOB.bind(this);

        this.state = {
            name: '',
            surname: '',
            email: '',
            dob: ''
        }
    }

    onChangeName(e) {
        this.setState({
            name: e.target.value
        });
    }

    onChangeSurname(e) {
        this.setState({
            surname: e.target.value
        });
    }

    onChangeEmail(e) {
        this.setState({
            email: e.target.value
        });
    }

    onChangeDOB(e) {
        this.setState({
            dob: e.target.value
        });
    }

    onSubmit(e) {
        e.preventDefault();
        const user = {
            name: this.state.name,
            surname: this.state.surname,
            email: this.state.email,
            dob: this.state.dob
        };
        axios.post('http://localhost/khomba/Create.php', user)
            .then(res => console.log(res.data));
        //console.log(userOBJ);
    }

    render() {
        return (
            
            <div style={{ marginTop: 10 }}>
                <div id="khombaElements">
                    <div id="khombaform">
                        <h3 align="center">SignUp</h3>
                        <form onSubmit={this.onSubmit}>
                        <div className="form-group">
                            <input type="text" placeholder="Name" className="form-control"
                                value={this.state.name} onChange={this.onChangeName} />
                        </div>
                        <div className="form-group">
                            <input type="text" placeholder="Surname" className="form-control"
                                value={this.state.surname} onChange={this.onChangeSurname} />
                        </div>
                        <div className="form-group">
                                <input type="email" placeholder="user@email.com" className="form-control"
                                    value={this.state.email} onChange={this.onChangeEmail} />
                        </div>
                        <div className="form-group">
                            <input type="date" placeholder="dd/MM/yyyy" width="300px" className="form-control"
                                value={this.state.dob} onChange={this.onChangeDOB} />
                            </div>
                            <div className="form-group">
                                <input type="password" placeholder="Password" width="300px" className="form-control"
                                     />
                            </div>
                            <br></br>
                        <div className="form-group">
                                <input type="submit" value="Sign up" className="btn btn-primary"
                                    value={this.state.onSubmit} onChange={this.onSubmit} />
                        </div>
                        </form>
                    </div>
                </div>
                </div>
            )
    }
}