import React, { Component } from 'react';

export default class Delete extends Component {
    render() {
        return (
            <div>
                <p> Delete new user finally </p>
            </div>
        )
    }
}
