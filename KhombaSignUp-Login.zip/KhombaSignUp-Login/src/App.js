import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Create from './CRUD/Create';
import Read from './CRUD/Read';
import Login from './Functions/Login';
import ReactPlayer from 'react-player';
import './App.css';
import Footer from './inc/Footer';
import Header from './inc/Header';

function App() {
    return (
        <Router>
            <div className="page-container">
                <Header/>
                <div className="content-wrap">
                <nav className="navbar navbar-expand-lg navbar-light bg-light">
                    <Link to={'/'} className="navbar-brand">KHOMBA</Link>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-item">
                                <Link to={'/read'} className="nav-link">| Khomba Users |</Link>
                            </li>
                            <li className="nav-item">
                                <Link to={'/create'} className="nav-link">Sign Up | </Link>
                            </li>
                            <li className="nav-item">
                                <Link to={'/login'} className="nav-link">Login</Link>
                            </li>
                        </ul>
                    </div>
                </nav>
                    <h2>
                        <br></br>FUTURE MOVEMENT <br></br><br></br>
                    </h2>
                <div id="khombavid">
                    <ReactPlayer controls autoPlay width="480px" url='KhombaVideo.mp4' />
                </div>
                <Switch>
                    <Route exact path='/create' component={Create} />
                    <Route path='/read' component={Read} />
                    <Route path='/login' component={Login} />
                    </Switch>
                    </div>
                <Footer />
            </div>
        </Router>
  );
}
export default App;
