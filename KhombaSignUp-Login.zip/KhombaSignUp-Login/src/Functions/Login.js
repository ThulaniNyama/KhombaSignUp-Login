import React, { Component } from 'react';
import axios from 'axios';

export default class Create extends Component {

    render() {
        return (

            <div style={{ marginTop: 10 }}>
                <div id="khombaElements">
                    <div id="khombaform">
                        <h3 align="center">Login</h3>
                        <form onSubmit={this.onSubmit}>
                            
                            <div className="form-group">
                                <input type="email" placeholder="user@email.com" className="form-control"
                                     />
                            </div>
                            <div className="form-group">
                                <input type="password" placeholder="Password" width="300px" className="form-control"
                                />
                            </div>
                            <br></br>
                            <div className="form-group">
                                <input type="submit" value="Login" className="btn btn-primary" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        )
    }
}